# South Sudan dynamic infrastructure layers, 2018–2025: sources and methods

Every layer uses the same temporal shape as the existing Trend Explorer layers: one feature per site **and status period**, with `valid_from` / `valid_to` as ISO dates (`YYYY-MM-DD`), clipped to 2018-01-01 → 2025-12-31. A month on the slider shows a feature when `valid_from <= month_end` and `valid_to >= month_start`. Each feature carries a `status` and an `evidence` string that states where the status came from.

No source publishes facility-by-facility opening and closing dates for South Sudan. Most of the timelines below come from comparing dated snapshots (registry lists, surveys, enrolment exports) and layering documented events on top. Where an opening or closing date can only be bracketed between two snapshots, the layer starts or ends the feature at the snapshot date and the `evidence` field gives the bracket. No date is interpolated.

## Files

| File | Grain | Period |
|---|---|---|
| `health_facilities_status_2018_2025.geojson` / `.csv` | facility × status period | 2018–2025 |
| `schools_status_2018_2025.geojson` / `.csv` | school × status period | 2018–2025 |
| `oil_wells_status_2018_2025.geojson` | OSM well × block status period | 2018–2025 |
| `oil_pipelines_status_2018_2025.geojson` | OSM pipeline segment × block status period | 2018–2025 |
| `oil_block_status_timeline_2018_2025.csv` | block system × status period | 2018–2025 |
| `ethnic_groups_geoepr_2018_2021.geojson` | ethnic group polygon | 2018–2021 |
| `protection_gbv_partner_presence_county_month_2019_2025.csv` | county × month (join on `adm2_pcode`) | Jan 2019 – Dec 2025 (Dec 2020 missing) |
| `context_events_2018_2025.csv` | dated national, state and county events with source URLs | 2018–2025 |
| `scripts/` | the Python that produced each file | |

## Health facilities

**Snapshots combined (all from HDX):**
1. South Sudan MoH facility list, update v1, April 2016 (`List_HF_SS_MoH_update_v1_20160404.xls`). This list has a `FUNCTIONAL Status` column (648 Functional, 31 Non Functional, 784 blank).
2. IOM DTM Village Assessment, health facilities, Aug 2019 – Mar 2020 (7 counties: Wau, Rubkona, Bor South, Torit, Magwi, Aweil Centre, Malakal). This survey records operational status, the reason a facility is non-operational and the month it stopped. Interviewee names and phone numbers in the source are not carried over.
3. MoH Final Master List of HFs & Codes 2023 (published 15 Jun 2024).
4. WHO Master Facility List, sheet `hsf_master_facility_list_202403` (posted April 2025).

**Matching.** The snapshots share no common ID, so records were linked by name and location within the same state. A match needs one of: distance ≤0.3 km with name similarity ≥35; ≤1 km and ≥60; ≤3 km and ≥70; ≤15 km and ≥88; or no coordinates and ≥92 (RapidFuzz token-set ratio after facility-type words are stripped). The 2016 list uses the old county names, so the matching relies on state plus coordinates. 461 matched records have no coordinates in any snapshot and are dropped from the map. That leaves 2,275 mapped facilities.

**Status rules.**
- In 2016 and in the 2023 or 2024 list → `registered` for the whole window.
- Not in 2016, first seen in the 2023 or 2024 list → `registered (new since 2016)` from that list's date. The facility opened somewhere between April 2016 and that list. It is **not** shown for 2018–2022, because no source places it there.
- In 2016 and absent from both later lists → `unconfirmed` through Dec 2023. It was dropped from the registry at an unknown date.
- Non-functional in 2016 → shown as non-functional until a later list includes it again. No reopening date is assumed.
- IOM DTM non-operational → `non-functional (IOM DTM)` from the reported "since" month (or Jan 2018 if earlier) to March 2020.
- Documented events: Ulang (registered as Ulang PHCC, run by MSF as a hospital), looted 14 Apr 2025 and permanently closed; Old Fangak Hospital, bombed 3 May 2025.

**Caveats.** A listing in the registry does not show that a facility was functional. Neither later list reports functionality. After matching, 11.5% of the 618 mapped "new since 2016" facilities still sit within 300 m of a 2016 facility, so some of them are probably renamed or respelled facilities rather than new ones. Aggregate closures that the sources do not attribute to named facilities are in `context_events_2018_2025.csv`. These include the 2025 aid cuts: Northern Bahr el Ghazal primary facilities fell from 180 to 61, Save the Children closed 7 facilities in Jonglei, and the MoH HSTP cut its supported facilities from 1,158 to 816. Insecurity Insight attacks are already a separate layer in the explorer.

## Schools

**Sources.**
1. SSSAMS school list with 2015 enrolment, including `Closed` and `Closed Date` fields (HDX, 5,048 schools; 4,861 have usable coordinates).
2. SSSAMS enrolment export dated 29 Oct 2019 (HDX `enrolment_28_2019-10-29.csv`, 6,383 schools under the 28-state structure, joined to the 2015 list on school code). 4,490 schools report more than zero learners. 1,541 codes in this export have no 2015 record, and therefore no coordinates, so they cannot be mapped.
3. IOM DTM Village Assessment, education facilities, Aug 2019 – Mar 2020 (560 schools; operational status, reason and month it stopped). 119 matched an SSSAMS school (≤5 km, name similarity ≥70). The other 392 are added as `DTM-xxxx` points, so a few may duplicate an SSSAMS school.
4. National closures: COVID-19 closure from 20 Mar 2020 to 2 May 2021, built into every school's timeline (candidate classes P8/S4 resumed 5 Oct 2020). Heatwave closures in March 2024 and February–March 2025 are listed in `context_events_2018_2025.csv` and not split into each school, which would double the feature count for two-week events.

**Status rules.** 2019 enrolment above zero → `operating (reported 2019 enrolment)`. Listed with zero learners → `listed, zero enrolment reported 2019`. Marked closed in SSSAMS with no 2019 learners → `closed (SSSAMS)` for the whole window. A DTM non-operational finding overrides the base status from its "since" month. After the COVID-19 reopening the base status continues, flagged `[carried forward: not observed after 2019-20]`, because no school-level public source for 2021–2025 was found. The SSSAMS website (sssams.org) has lapsed, and its archived copies could not be reached from this environment. The MoGEI Annual Education Census (2023: 17% of schools non-operational) is published only as aggregates.

## Oil wells, pipelines and blocks

**Geometry.** OpenStreetMap through the HOT Raw Data API (`api-prod.raw-data.hotosm.org`), extracted 15 Nov 2026 for two boxes: Melut Basin (31.6–33.6E, 9.2–11.1N) and Unity/Ruweng (28.7–30.8E, 8.1–10.2N). The extract holds 169 pipeline segments and 102 wells (`man_made=petroleum_well/oil_well`). Water pipelines are excluded. Each feature is assigned to a block system by location: east of 31E → Blocks 3 & 7. Guit, Koch, Leer, Mayendit and Panyijiar counties → Block 5A. Everything else → Blocks 1, 2 & 4.

**Status periods (documented, see `oil_block_status_timeline_2018_2025.csv`):**
- Blocks 3 & 7 (Petrodar): operating → halted 6 Feb 2024 (pipeline rupture in Sudan, force majeure March 2024) → restarted 8 Jan 2025.
- Blocks 1, 2 & 4 (GPOC): shut since 2013 → Toma South restarted 25 Aug 2018 → Unity fields restarted 21 Jan 2019 → disrupted 8 Dec 2025, when the RSF seized the Heglig processing hub.
- Block 5A (SPOC, Thar Jath): shut since 2013–14 → restarted 21 Jun 2021 → disrupted 8 Dec 2025 (its crude also routes to Heglig).

These are block-level statuses applied to every well and pipeline in the block, not well-by-well observations.

**Satellite test that did not work.** The plan was a monthly per-field operating signal from gas-flare hot spots. NASA MODIS MOD14A2/MYD14A2 8-day 1 km fire masks for 2018–2025 (2,848 tiles, Microsoft Planetary Computer) were tested first. Persistent wet-season hot spots near Paloch, Toma South and Thar Jath were too sparse, at 0–3 composites a year, and showed no drop during the documented 2024 Paloch shutdown. The result was therefore left out. The scripts are kept in `scripts/modis_fire.py` and `scripts/flares.py`. The better instrument is VIIRS (375 m): FIRMS VIIRS archive records carry `type = 2` ("other static land source"), which marks gas flares, and the yearly country CSVs from FIRMS (`viirs-snpp_<year>_South_Sudan.csv` and `..._Sudan.csv`, for Heglig) would give the monthly signal. The FIRMS host could not be reached from this environment, so those files would need to be downloaded in a browser. EOG's VIIRS Nightfire product is the alternative (free account).

## Ethnic group areas

ETH Zurich GeoEPR-2021 polygons, joined to EPR-2021 core attributes (population share, power status) and ACD2EPR-2021 links to rebel organisations. South Sudan has a single EPR period, 2011–2021, so the 10 polygons and their power statuses do not change inside the window. The layer runs from Jan 2018 to Dec 2021, when the dataset ends. Geometry is simplified at 0.005° tolerance.

## "Crisis resource centres": protection and GBV partner presence

No public point dataset of GBV one-stop centres, women and girls' friendly spaces or protection desks with dates was found on HDX. The IOM DTM site assessments (rounds 4–11) cover only about 80–90 sites and record one GBV-care field, in round 11 only. As a stand-in, this file counts **distinct organisations reporting Protection-cluster activity** in each county each month, from OCHA's 3W Operational Presence files for 2019–2025. In South Sudan the Protection cluster covers the GBV, child protection and mine action areas of responsibility, and the 3W does not separate them. Join to admin-2 polygons on `adm2_pcode` (OCHA COD boundaries). `partner_change_vs_prev_month` marks months when partners arrived or left. The file layout and reporting coverage change from year to year (for example, 2023–2024 have more county-months at zero), so changes within a year are more reliable than comparisons between years.

## Other sources cited
News and agency sources for each dated event are listed with URLs in `context_events_2018_2025.csv` (MSF, Save the Children, Eye Radio, Radio Tamazuj, Sudan Tribune, Sudans Post, VOA, AFP/New Arab, UNICEF, Education Cluster/HNRP).

---

# Addendum (15 Nov 2026): water pollution, GBV one-stop centres and nutrition

## Water pollution

The public record holds no repeated ground-truth water-quality monitoring for South Sudan. No national network appeared in HDX, GEMStat or WPdx with dated samples. Four kinds of evidence are combined instead, and each one measures something different.

**1. `oil_spills_2018_2025.geojson`: documented, geolocated spills.** Two ruptures of the Unity–Heglig export pipeline, each with GPS coordinates, date and estimated volume from Sign of Hope's satellite and on-site investigation (Feb 2020):
- Spill 1: about 24 Aug 2019, ~2 million L.
- Spill 2: about 28 Oct 2019, ~4 million L.

The repairs are documented, but removal of the spilled oil is not, so after the active period each site continues as "spill site; oil removal not documented". The Feb 2024 Petrodar spill in Sudan, which stopped Blocks 3 & 7 exports, is included and flagged as outside South Sudan (PAX).

**2. `oil_wells_flooding_monthly_2018_2025.csv` / `oil_wells_flooding_status_2018_2025.geojson`: satellite check of flood water around each oil well.** Journalists and PAX report that the 2021 floods left dozens of Unity wells underwater, and the current reporting on contamination centres on these submerged wells. For each of the 102 OSM wells and each Sentinel-1 acquisition from 2018 to 2025 (33,550 well-acquisitions; Sentinel-1 RTC on Microsoft Planetary Computer), the script computes the share of pixels below −15 dB VV (open water) in a ring 100–500 m around the well. Monthly medians follow, and a well counts as having flood water around it when that share is at least 25%.
- Wells flagged at least once per year: 2018: 10, 2019: 9, 2020: 8, 2021: 0, 2022: 4, 2023: 16, 2024: 10, 2025: 2.
- Median open-water share rose from about 0.1% (2018–2021) to 1–3.5% (2022–2025).
- Caveats:
  - Flooded marsh with emergent vegetation scatters radar brightly, not darkly, so this method undercounts inundation. The near-zero 2021 is probably an artefact of that and of the loss of Sentinel-1B in Dec 2021.
  - OSM maps only about 100 of the roughly 400 wells in Unity.
  - The method detects water around a well, not contamination.

**3. `surface_water_optical_quality_monthly_2018_2025.csv` / `.geojson`: monthly optical water-quality indices.** Eight river and wetland sites, each about 11 × 11 km:
- White Nile at Juba, Bor, Malakal, Melut and Renk (upstream → beside → downstream of the Melut Basin oil fields)
- Sobat at Nasir (no oil)
- Bentiu wetland (Unity fields)
- Thar Jath wetland (Block 5A)

The source is NASA HLS v2 (Harmonized Landsat–Sentinel-2, 30 m) from 2020 to 2025. The Planetary Computer HLS catalogue has no 2019 scenes and almost none for 2018, so those years use Sentinel-2 L2A (same bands; scene classification class 6 = water). Water pixels only, with cloud and shadow removed; at most the 3 clearest scenes per site per month (2,402 scenes). Fields:
- `ndti` = (red − green)/(red + green), a turbidity and suspended-sediment proxy
- `red_reflectance`
- `ndci` = (red edge 1 − red)/(red edge 1 + red), a chlorophyll proxy
- `*_anomaly` = the value minus that site's median for the same calendar month, which removes the normal seasonal sediment cycle

Coverage is 89–94 of 96 months for the river sites and only 15 months for the Thar Jath wetland, which is mostly vegetated and rarely shows open water.
- **These indices measure sediment and algae, not oil, heavy metals or salinity.** They show changes in the water, but they cannot show that it is contaminated. The White Nile sites upstream, beside and downstream of the oil fields show no consistent downstream step.
- HLS and Sentinel-2 L2A differ slightly in processing, so 2018–2019 values may be offset from 2020–2025.

**4. `water_pollution_events.csv`: sourced context.**
- Sign of Hope's 2008–2013 hydrogeological baseline (salinity and heavy metals in shallow wells around Thar Jath and Mala)
- The 2016 hair-sample results
- The flooded-well findings (PAX 2023; New Lines/Placemark 2026)
- Kuer's river samples near Bentiu and Rotriak (lead up to 18 µg/L; hydrocarbons more than 5 times the limits; sampling dates not published in coverage)
- The September 2022 announcement of a government environmental audit
- The 2024–2025 cholera outbreak (a marker of faecal contamination), with county totals from the WHO one-year factsheet

## GBV one-stop centres and rape-crisis services: `gbv_one_stop_centres_2018_2025.geojson` / `.csv`

There are 13 one-stop centres (OSCs), which provide clinical management of rape, psychosocial, legal and police services, plus the Bentiu safe house. They were compiled from:
- UNFPA (Juba opened Nov 2017; Rumbek, Malualkon and Wau planned Jul 2018)
- the FAO/World Bank ELRP GBV action plans (OSC tables as of Dec 2019 and Dec 2021)
- UNICEF's May 2020 sitrep (Yei, Yambio)
- UNFPA's 2021 annual report (Bentiu OSC and safe house, the 13th OSC)
- UNFPA's Q1 2023 newsletter (13 OSCs operating; Kapoeta opened in 2019)

Each site's coordinates are those of its host facility in the WHO Master Facility List. `valid_from` is the **first date with evidence that the site was operating**, not necessarily its opening date. Where a source gives only a year, the date is the end of that year. Every site is documented as operating through Q1 2023 and shown as "presumed operating" after that. No source after Q1 2023 confirms individual sites, and that period includes the 2025 funding cuts.

No public point data with dates was found for women and girls' friendly spaces, GBV referral pathways or protection desks. GBV sub-cluster service maps exist only as PDFs.

## Nutrition sites: `nutrition_partner_presence_county_month_2019_2025.csv`

No list of nutrition sites (OTP, TSFP or stabilisation centres) is published with locations and dates. The Nutrition Cluster collects site names through its reporting forms but does not publish them. OpenStreetMap and healthsites hold only 4–5 feeding centres. As a stand-in, this file counts, using the same method as the protection table, how many organisations reported Nutrition-sector activity in each county each month in OCHA's 3W (2019–2025). Join on `adm2_pcode`. The same caveat applies: the 3W format changes between years.
