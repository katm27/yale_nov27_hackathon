# Fill 2018-2019 gap in the Planetary Computer HLS v2 catalogue with Sentinel-2 L2A (same bands; SCL class 6 = water).
import sys, csv, numpy as np, rasterio, planetary_computer as pc, pandas as pd
from rasterio.windows import from_bounds
from rasterio.warp import transform_bounds
from pystac_client import Client
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0, '/home/claude/scripts')
out = sys.argv[1]
src = open('/home/claude/scripts/hls_water.py').read()
AOIS = eval(src[src.index('AOIS = {') + 7: src.index('}\nH = ') + 1])
H = 0.05
cat = Client.open('https://planetarycomputer.microsoft.com/api/stac/v1', modifier=pc.sign_inplace)
jobs = []
for name, (x, y, role) in AOIS.items():
    bb = [x - H, y - H, x + H, y + H]
    its = list(cat.search(collections=['sentinel-2-l2a'], bbox=bb, datetime='2018-01-01/2019-12-31', query={'eo:cloud_cover': {'lt': 80}}).items())
    df = pd.DataFrame([dict(i=i, m=it.datetime.strftime('%Y-%m'), cc=it.properties['eo:cloud_cover']) for i, it in enumerate(its)])
    keep = df.sort_values('cc').groupby('m').head(3).i
    jobs += [(name, bb, its[i]) for i in keep]
    print(name, len(its), len(keep), flush=True)
def rd(href, bb, shape=None):
    with rasterio.open(href) as s:
        b = transform_bounds('EPSG:4326', s.crs, *bb)
        w = from_bounds(*b, s.transform)
        return s.read(1, window=w, out_shape=shape, boundless=True, fill_value=0)
def work(j):
    name, bb, it = j
    try:
        scl = rd(it.assets['SCL'].href, bb); shp = scl.shape
        water = scl == 6; n = int(water.sum())
        row = dict(aoi=name, date=it.datetime.strftime('%Y-%m-%d'), sensor='sentinel-2-l2a', scene=it.id, water_px=n, clear_px=int(np.isin(scl, [4, 5, 6, 7, 11]).sum()), total_px=int(scl.size))
        if n < 150: return row
        g = rd(it.assets['B03'].href, bb, shp).astype('float32') / 1e4
        r = rd(it.assets['B04'].href, bb, shp).astype('float32') / 1e4
        re = rd(it.assets['B05'].href, bb, shp).astype('float32') / 1e4
        ok = water & (g > 0) & (r > 0) & (g < .5) & (r < .5)
        ok2 = ok & (re > 0) & (re < .5)
        row.update(green=float(np.median(g[ok])), red=float(np.median(r[ok])), ndti=float(np.median((r[ok] - g[ok]) / (r[ok] + g[ok]))),
                   ndci=float(np.median((re[ok2] - r[ok2]) / (re[ok2] + r[ok2]))) if ok2.sum() > 100 else None)
        return row
    except Exception as e:
        return dict(aoi=name, date=it.datetime.strftime('%Y-%m-%d'), sensor='sentinel-2-l2a', scene=it.id, error=str(e)[:100])
cols = ['aoi', 'date', 'sensor', 'scene', 'water_px', 'clear_px', 'total_px', 'green', 'red', 'ndti', 'ndci', 'error']
with ThreadPoolExecutor(32) as ex, open(f'{out}/s2_fill_scenes.csv', 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=cols); w.writeheader()
    for i, r in enumerate(ex.map(work, jobs)):
        w.writerow(r)
        if i % 100 == 0: print(i, len(jobs), flush=True)
print('done', flush=True)
