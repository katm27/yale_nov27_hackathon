import sys, re, json, math, pandas as pd, numpy as np
from rapidfuzz import fuzz
raw, out = sys.argv[1], sys.argv[2]
STOP = r'\b(phcu|phcc|hospital|hosp|clinic|health|centre|center|unit|primary|care|civil|teaching|the|hc|pccu|phc|county|state|rhc|of|and)\b'
def norm(s): s = re.sub(r'[^a-z0-9 ]', ' ', str(s).lower()); s = re.sub(STOP, ' ', s); return re.sub(r'\s+', ' ', s).strip()
def st(s): s = str(s).lower().replace('state', '').strip(); return {'abyei': 'abyei region', 'abyei aa': 'abyei region', 'abyei adminstrative area': 'abyei region', 'cent eq': 'central equatoria', 'east eq': 'eastern equatoria', 'west eq': 'western equatoria', 'north bahr': 'northern bahr el ghazal', 'west bahr': 'western bahr el ghazal'}.get(s, s)
def ftype(n, t=None):
    s = f'{t} {n}'.lower()
    return 'Hospital' if 'hosp' in s else 'PHCC' if 'phcc' in s else 'PHCU' if 'phcu' in s else (t or 'Other')
recs = []
a = pd.read_excel(f'{raw}/mfl2025.xlsx')
for r in a.itertuples(): recs.append(dict(src='MFL2024', name=r.site_dhis2_name if isinstance(r.site_dhis2_name,str) else str(r.site).title(), state=st(r.old_state), county=str(r.county).lower(), lat=r.latitude, lon=r.longitude, type=ftype(r.site), code=r.payam_code))
b = pd.read_excel(f'{raw}/mfl2023.xlsx', sheet_name=0)
for r in b.itertuples(): recs.append(dict(src='MFL2023', name=r.Facility_Name, state=st(r.State), county=str(r.County).lower(), lat=r.Latitude, lon=r.Longitude, type=ftype(r.Facility_Name, r.Type), code=r.Facilities_Code))
c = pd.read_excel(f'{raw}/moh2016.xls', sheet_name=0)
for r in c.itertuples(): recs.append(dict(src='MOH2016', name=r.FACIL_NAME2, state=st(r.STATE), county=str(r.COUNTY).lower(), lat=r.LATITUDE, lon=r.LONGITUDE, type=ftype(r.FACIL_NAME2, r.HF_TYPE), status2016=r._12 if isinstance(r._12, str) else 'Not recorded'))
c2 = pd.read_excel(f'{raw}/moh2016.xls', sheet_name='New facilities')
for r in c2.itertuples(): recs.append(dict(src='MOH2016', name=r.FACIL_NAME2, state=st(r.STATE), county=str(r.COUNTY).lower(), lat=np.nan, lon=np.nan, type=ftype(r.FACIL_NAME2, r.HF_TYPE), status2016=r.FUNCTIONAL if isinstance(r.FUNCTIONAL, str) else 'Not recorded'))
d = pd.read_excel(f'{raw}/dtm_hf.xlsx', sheet_name=0)
cols = {k: [c for c in d.columns if c.startswith(k)][0] for k in ['Name of Health', 'Latitude_Ref', 'Longitude_Ref', '2. a)', '2. b) If', '2. c)', '1. Type']}
for r in d.to_dict('records'):
    recs.append(dict(src='DTM2020', name=r[cols['Name of Health']], state=st(r['State']), county=str(r['County']).lower(), lat=pd.to_numeric(r[cols['Latitude_Ref']], errors='coerce'), lon=pd.to_numeric(r[cols['Longitude_Ref']], errors='coerce'), type=ftype(r[cols['Name of Health']], r[cols['1. Type']]),
        dtm_status=r[cols['2. a)']], dtm_reason=r[cols['2. b) If']], dtm_since=r[cols['2. c)']]))
for x in recs:
    x['n'] = norm(x['name'])
    if not (isinstance(x['lat'], float) and -1 < x['lat'] < 14 and 22 < x['lon'] < 37): x['lat'] = x['lon'] = np.nan
def km(a, b): return 6371 * 2 * math.asin(math.sqrt(math.sin(math.radians(b['lat'] - a['lat']) / 2) ** 2 + math.cos(math.radians(a['lat'])) * math.cos(math.radians(b['lat'])) * math.sin(math.radians(b['lon'] - a['lon']) / 2) ** 2))
clusters = []
for src in ['MFL2024', 'MFL2023', 'MOH2016', 'DTM2020']:
    for x in [r for r in recs if r['src'] == src]:
        best, bs = None, 0
        for cl in clusters:
            h = cl['head']
            if src in cl['members']: continue
            if h['state'] != x['state'] and not (h['state'] in x['state'] or x['state'] in h['state']): continue
            s = max(fuzz.token_set_ratio(x['n'], h['n']), fuzz.ratio(x['n'], h['n'])) if x['n'] and h['n'] else 0
            if x['type'] != h['type']: s -= 8
            haveC = not math.isnan(x['lat']) and not math.isnan(h['lat'])
            dk = km(x, h) if haveC else None
            ok = (haveC and ((dk <= 0.3 and s >= 35) or (dk <= 1 and s >= 60) or (dk <= 3 and s >= 70) or (dk <= 15 and s >= 88))) or (not haveC and s >= 92)
            sc = s - (2 * dk if haveC else 5)
            if ok and sc > bs: best, bs = cl, sc
        if best: best['members'][src] = x; best['score'] = min(best.get('score', 100), bs)
        else: clusters.append({'head': x, 'members': {src: x}})
# coords fallback
for cl in clusters:
    for s in ['MFL2024', 'MFL2023', 'MOH2016', 'DTM2020']:
        m = cl['members'].get(s)
        if m is not None and not math.isnan(m['lat']): cl['lat'], cl['lon'] = m['lat'], m['lon']; break
events = json.load(open(f'{raw}/health_events.json'))
feats = []; WIN0, WIN1 = '2018-01-01', '2025-12-31'
def add(cl, fid, status, f, t, evidence):
    if f > t: return
    h = cl['head']
    feats.append({'type': 'Feature', 'geometry': {'type': 'Point', 'coordinates': [round(cl['lon'], 6), round(cl['lat'], 6)]},
        'properties': {'facility_id': fid, 'name': h['name'], 'type': h['type'], 'state': h['state'].title(), 'county': h['county'].title(),
        'status': status, 'valid_from': f, 'valid_to': t, 'evidence': evidence,
        'in_moh_2016': 'MOH2016' in cl['members'], 'in_mfl_2023': 'MFL2023' in cl['members'], 'in_who_mfl_2024': 'MFL2024' in cl['members'],
        'moh_2016_status': cl['members'].get('MOH2016', {}).get('status2016'), 'match_score_min': cl.get('score')}})
nolocs = 0
for i, cl in enumerate(clusters):
    if 'lat' not in cl: nolocs += 1; continue
    fid = f'SSD-HF-{i:05d}'; m = cl['members']
    in16, in23, in24 = 'MOH2016' in m, 'MFL2023' in m, 'MFL2024' in m
    s16 = m.get('MOH2016', {}).get('status2016')
    ev = [e for e in events if (in23 or in24) and fuzz.token_set_ratio(norm(e['match']), cl['head']['n']) >= 90 and e['state'] == cl['head']['state'] and (e.get('type') in (None, cl['head']['type']))]
    end = WIN1; tail = None
    if ev:
        e = sorted(ev, key=lambda e: e['date'])[0]; end = (pd.Timestamp(e['date']) - pd.Timedelta(days=1)).strftime('%Y-%m-%d'); tail = e
    periods = []
    if in16:
        first = WIN0
        if s16 == 'Non Functional':
            relist = '2023-12-01' if in23 else '2024-03-01' if in24 else None
            if relist:
                periods.append(('non-functional in 2016; status unknown until relisted', WIN0, (pd.Timestamp(relist) - pd.Timedelta(days=1)).strftime('%Y-%m-%d'), f'MoH 2016 list marks it Non Functional; it reappears in the {"2023 MoH" if in23 else "Mar 2024 WHO"} master list. Reopening date unknown.'))
                first = relist
            else:
                periods.append(('non-functional in 2016; absent from 2023 and 2024 lists', WIN0, '2023-12-31', 'MoH 2016 list marks it Non Functional and it is absent from later master lists'))
                continue_flag = True
        if s16 == 'Non Functional' and not (in23 or in24):
            pass
        elif in23 or in24:
            periods.append(('registered', first, end, 'Listed in MoH 2016 and in 2023 and/or 2024 master facility lists'))
        else:
            periods.append(('unconfirmed: in 2016 list, absent from 2023 and 2024 lists', first, '2023-12-31', 'Dropped from the national master list by 2023; closure date unknown (somewhere between Apr 2016 and the 2023 list)'))
    elif 'DTM2020' in m and not (in23 or in24):
        periods.append(('registered', '2019-08-01', '2020-03-31', 'Only seen in IOM DTM village assessment (Aug 2019-Mar 2020)'))
    else:
        firstlist = '2023-12-01' if in23 else '2024-03-01'
        periods.append(('registered (new since 2016)', firstlist, end, f'Absent from MoH 2016 list; first appears in {"2023 MoH master list" if in23 else "WHO MFL (Mar 2024 extract)"}. Opened sometime between Apr 2016 and that list.'))
        if 'DTM2020' in m:
            periods.insert(0, ('registered', '2019-08-01', (pd.Timestamp(firstlist) - pd.Timedelta(days=1)).strftime('%Y-%m-%d'), 'Seen operating/listed in IOM DTM village assessment Aug 2019-Mar 2020, before entering the national list'))
    dm = m.get('DTM2020')
    if dm is not None and str(dm.get('dtm_status')) == 'Non-operational':
        since = pd.to_datetime(dm.get('dtm_since'), errors='coerce')
        f = max(since.strftime('%Y-%m-%d'), WIN0) if pd.notna(since) else '2019-08-01'
        periods = [p for p in periods if not (p[3].startswith('Only seen in IOM DTM'))]
        periods.append(('non-functional (IOM DTM)', f, '2020-03-31', f"IOM DTM village assessment: Non-operational, reason: {dm.get('dtm_reason')}, since {since.date() if pd.notna(since) else 'unknown'}"))
        # trim overlapping registered periods
        newp = []
        for s, a_, b_, e_ in periods:
            if s.startswith('non-functional (IOM'): newp.append((s, a_, b_, e_)); continue
            if a_ < f <= b_: newp.append((s, a_, (pd.Timestamp(f) - pd.Timedelta(days=1)).strftime('%Y-%m-%d'), e_)); 
            if a_ <= '2020-03-31' < b_: newp.append((s, '2020-04-01', b_, e_ + '; status after Mar 2020 not observed'))
            if not (a_ < f <= b_) and not (a_ <= '2020-03-31' < b_): newp.append((s, a_, b_, e_))
        periods = newp
    for s, a_, b_, e_ in periods:
        add(cl, fid, s, max(a_, WIN0), min(b_, WIN1), e_)
    if tail and tail['date'] <= WIN1:
        add(cl, fid, tail['status'], tail['date'], WIN1, f"{tail['what']} Source: {tail['source']}")
json.dump({'type': 'FeatureCollection', 'features': feats}, open(f'{out}/health_facilities_status_2018_2025.geojson', 'w'))
pd.DataFrame([f['properties'] for f in feats]).to_csv(f'{out}/health_facilities_status_2018_2025.csv', index=False)
print('clusters', len(clusters), 'no coords', nolocs, 'features', len(feats))
print(pd.Series([f['properties']['status'] for f in feats]).value_counts())
