import json, pandas as pd
def dms(d, m, s): return round(d + m / 60 + s / 3600, 6)
SOH = 'Sign of Hope, "Causing a Black Tide of Oil" (25 Feb 2020) and UN written statement 2020; https://www.hoffnungszeichen.de/sites/default/files/documents/causing_a_black_tide_of_oil_-_south_sudans_polluting_pipeline_-_sign_of_hope.pdf'
pts = [
 ('Oil spill 1: Unity-Heglig export pipeline rupture', dms(29, 37, 36.83), dms(9, 36, 49.83), [
   ('oil spill (active)', '2019-08-24', '2019-10-15', 'Rupture on or about 24 Aug 2019, ~40 km north of Rubkona; ~12,500 bbl (2 million L) over ~10,000 m2, measured from satellite imagery and an on-site visit'),
   ('spill site; pipeline repaired, oil removal not documented', '2019-10-16', '2025-12-31', 'Pipeline repaired mid-Oct 2019; Sign of Hope found no documented disposal of spilled oil as of Feb 2020')]),
 ('Oil spill 2: Unity-Heglig export pipeline rupture', dms(29, 38, 42.85), dms(9, 33, 33.16), [
   ('oil spill (active)', '2019-10-28', '2020-02-29', 'Rupture on or about 28 Oct 2019, ~33.5 km north of Rubkona; ~25,000 bbl (4 million L) over ~20,000 m2'),
   ('spill site; pipeline repaired, oil removal not documented', '2020-03-01', '2025-12-31', 'Repair observed during Feb 2020 on-site visit; disposal of spilled oil not documented')]),
 ('Petrodar pipeline spill, White Nile State (Sudan)', 32.269815, 14.700172, [
   ('oil spill (outside South Sudan)', '2024-02-01', '2024-03-31', 'Spill at the pipeline rupture that led to the March 2024 force majeure on Blocks 3 & 7 exports; identified by PAX from Planet/Sentinel-2 imagery')]),
]
srcs = {0: SOH, 1: SOH, 2: 'PAX for Peace, "Oil in the Crosshairs"; https://paxforpeace.nl/news/oil-in-the-crosshairs/'}
feats = []
for k, (name, lon, lat, per) in enumerate(pts):
    for st, a, b, ev in per:
        feats.append({'type': 'Feature', 'geometry': {'type': 'Point', 'coordinates': [lon, lat]}, 'properties': {'name': name, 'status': st, 'valid_from': max(a, '2018-01-01'), 'valid_to': b, 'evidence': ev, 'source': srcs[k]}})
json.dump({'type': 'FeatureCollection', 'features': feats}, open('/home/claude/out2/oil_spills_2018_2025.geojson', 'w'), indent=0)
ev = [
 ('Unity / Ruweng / Upper Nile oil fields', '2008-01-01', '2013-12-31', 'Sign of Hope hydrogeological study (published 2014): brine and heavy metals from oil operations raised salinity and contaminated shallow drinking-water wells around Thar Jath and Mala (Block 5A); pre-2018 baseline', 'https://www.hoffnungszeichen.de/sites/default/files/documents/zbl.geol_.palaeont._teil_i_jg._2014_heft_1_effect_of_oil_exploration_and_production.pdf'),
 ('Block 5A (Koch, Leer, Nyal)', '2016-03-04', '2016-03-04', 'Hair samples from 96 residents around Thar Jath showed high lead and barium (Forensic Science International); exposure context, not a water measurement', 'https://www.thestar.com.my/news/environment/2016/03/04/south-sudan-oil-production-pollution-threatens-thousands/'),
 ('Unity State', '2021-07-01', '2025-12-31', 'Extreme 2021 floods never fully receded; PAX (2023) found 159 Block 2 wells (~41%) submerged; New Lines/Placemark (early 2026) found 50+ of ~400 Unity wells still underwater. See oil_wells_flooding_monthly_2018_2025.csv for a satellite check at each mapped well', 'https://pulitzercenter.org/stories/living-edge-south-sudans-toxic-floodplains'),
 ('Nahm and Abuk rivers around Bentiu and Rotriak (Rubkona)', '2024-01-01', '2025-12-31', 'Kuer (Kenyatta University) reports lead up to 18 ug/L (about twice the WHO guideline) and hydrocarbons more than five times recommended limits; sampling dates not given in coverage', 'https://www.worldwidemagazine.org/?p=11460'),
 ('Unity and Upper Nile oil fields', '2022-09-01', '2022-09-30', 'Ministries of Petroleum and Environment announce an environmental audit of Blocks 3 & 7 (Paloch) and 1, 2, 4 and 5A (Unity); results not found in public sources', 'https://eyeradio.org/ruweng-alarmed-by-oil-pollution-as-it-records-3-birth-defects-in-2024/'),
 ('South Sudan (cholera, faecal contamination of water)', '2024-09-28', '2025-10-31', 'Largest cholera outbreak on record: first case 28 Sep 2024 in Renk, declared 28 Oct 2024; ~55 of 80 counties affected after 12 months. Most affected: Rubkona 19,557 cases, Juba 11,346, Mayom 6,084, Aweil West 5,361, Nyirol 5,320', 'https://www.afro.who.int/sites/default/files/2025-10/Knowledge%20Management%20Series%20for%20Health-%20Cholera%20in%20South%20Sudan%3B%20One%20Year%20On%20Factsheet..pdf'),
]
pd.DataFrame(ev, columns=['area', 'date_from', 'date_to', 'event', 'source_url']).to_csv('/home/claude/out2/water_pollution_events.csv', index=False)
print(len(feats))
