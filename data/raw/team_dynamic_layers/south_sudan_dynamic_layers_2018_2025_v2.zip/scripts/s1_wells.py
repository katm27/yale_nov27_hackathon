# Sentinel-1 RTC (VV, gamma0) open-water test at each OSM oil well, every acquisition 2018-2025.
import sys, json, csv, numpy as np, rasterio, planetary_computer as pc
from rasterio.warp import transform_bounds, transform as wtransform
from rasterio.windows import from_bounds
from pystac_client import Client
from concurrent.futures import ThreadPoolExecutor
wells_fn, out = sys.argv[1], sys.argv[2]
W = {}
for f in json.load(open(wells_fn))['features']:
    W[f['properties']['osm_id']] = f['geometry']['coordinates']
ids = list(W); xy = np.array([W[i] for i in ids])
# cluster wells into boxes (0.25 deg grid)
groups = {}
for i, (x, y) in zip(ids, xy): groups.setdefault((round(x * 4), round(y * 4)), []).append(i)
cat = Client.open('https://planetarycomputer.microsoft.com/api/stac/v1', modifier=pc.sign_inplace)
jobs = []
for k, mem in groups.items():
    pts = np.array([W[i] for i in mem]); bb = [pts[:, 0].min() - .01, pts[:, 1].min() - .01, pts[:, 0].max() + .01, pts[:, 1].max() + .01]
    its = list(cat.search(collections=['sentinel-1-rtc'], bbox=bb, datetime='2018-01-01/2025-12-31').items())
    print(k, len(mem), len(its), flush=True)
    jobs += [(mem, bb, it) for it in its]
RES = 30.0
def work(j):
    mem, bb, it = j
    try:
        with rasterio.open(it.assets['vv'].href) as s:
            b = transform_bounds('EPSG:4326', s.crs, *bb)
            w = from_bounds(*b, s.transform)
            sc = RES / s.transform.a
            shp = (max(1, int(w.height / sc)), max(1, int(w.width / sc)))
            a = s.read(1, window=w, out_shape=shp, boundless=True, fill_value=0)
            T = s.window_transform(w) * rasterio.Affine.scale(w.width / shp[1], w.height / shp[0])
            crs = s.crs
        rows = []
        xs, ys = wtransform('EPSG:4326', crs, [W[i][0] for i in mem], [W[i][1] for i in mem])
        for i, x, y in zip(mem, xs, ys):
            c, r = ~T * (x, y); r, c = int(r), int(c)
            R = 17  # ~500 m at 30 m
            win = a[max(r - R, 0):r + R + 1, max(c - R, 0):c + R + 1]
            yy, xx = np.mgrid[:win.shape[0], :win.shape[1]]
            cy, cx = r - max(r - R, 0), c - max(c - R, 0)
            ring = ((yy - cy) ** 2 + (xx - cx) ** 2 <= R * R) & ((yy - cy) ** 2 + (xx - cx) ** 2 >= 9)
            v = win[ring & (win > 0) & np.isfinite(win)]
            if v.size < 50: continue
            db = 10 * np.log10(v)
            rows.append((i, it.datetime.strftime('%Y-%m-%d'), it.properties.get('sat:orbit_state'), round(float(np.median(db)), 2), round(float((db < -15).mean()), 3)))
        return rows
    except Exception as e:
        return [('ERR', it.id, str(e)[:60], None)]
with ThreadPoolExecutor(24) as ex, open(f'{out}/s1_wells_ring.csv', 'w', newline='') as f:
    wr = csv.writer(f); wr.writerow(['osm_id', 'date', 'orbit', 'vv_db_median_500m', 'open_water_share_500m'])
    for n, rows in enumerate(ex.map(work, jobs)):
        wr.writerows(rows)
        if n % 100 == 0: print(n, len(jobs), flush=True)
print('done', flush=True)
