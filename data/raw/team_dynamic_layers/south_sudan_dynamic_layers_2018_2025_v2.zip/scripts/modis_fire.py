# Pull MODIS MOD14A2/MYD14A2 8-day FireMask (Terra+Aqua, 1 km) 2018-2025 for tiles over the oil region
# and save, per composite, every pixel with FireMask>=7 (fire, low/nominal/high confidence) plus
# per-composite cloud share over the oil box. Output: parquet-free CSVs for portability.
import sys, csv, numpy as np, rasterio, planetary_computer as pc
from pystac_client import Client
from concurrent.futures import ThreadPoolExecutor
from pyproj import Transformer
out = sys.argv[1]
cat = Client.open('https://planetarycomputer.microsoft.com/api/stac/v1', modifier=pc.sign_inplace)
items = []
for y in range(2018, 2026):
    for col in ['modis-14A2-061']:
        items += list(cat.search(collections=[col], bbox=[28.0, 7.8, 34.0, 12.3], datetime=f'{y}-01-01/{y}-12-31').items())
print('items', len(items), flush=True)
tr = Transformer.from_crs('+proj=sinu +R=6371007.181 +nadgrids=@null +wktext', 'EPSG:4326', always_xy=True)
def work(it):
    for attempt in range(3):
        try:
            with rasterio.open(it.assets['FireMask'].href) as src:
                a = src.read(1); T = src.transform
            break
        except Exception as e:
            err = e
    else:
        return [], (it.id, 'ERR', str(err)[:80])
    rows = []
    r, c = np.where(a >= 7)
    if len(r):
        xs, ys = rasterio.transform.xy(T, r, c)
        lon, lat = tr.transform(np.array(xs), np.array(ys))
        for i in range(len(r)):
            if 27.5 <= lon[i] <= 34.5 and 7.5 <= lat[i] <= 12.5:
                rows.append((it.id.split('.')[0], it.properties['start_datetime'][:10], it.id.split('.')[2], int(r[i]), int(c[i]), round(float(lon[i]), 5), round(float(lat[i]), 5), int(a[r[i], c[i]])))
    cloud = float((a == 4).mean()); valid = float((a >= 3).mean())
    return rows, (it.id, it.properties['start_datetime'][:10], round(cloud, 4), round(valid, 4))
with ThreadPoolExecutor(16) as ex, open(f'{out}/fire_pixels.csv', 'w', newline='') as f1, open(f'{out}/composites.csv', 'w', newline='') as f2:
    w1 = csv.writer(f1); w1.writerow(['sensor', 'start', 'tile', 'row', 'col', 'lon', 'lat', 'firemask'])
    w2 = csv.writer(f2); w2.writerow(['id', 'start', 'cloud_share', 'valid_share'])
    for n, (rows, meta) in enumerate(ex.map(work, items)):
        w1.writerows(rows); w2.writerow(meta)
        if n % 200 == 0: print(n, flush=True)
print('done', flush=True)
