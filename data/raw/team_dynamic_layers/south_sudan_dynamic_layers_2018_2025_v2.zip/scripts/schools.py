import sys, re, json, math, pandas as pd, numpy as np
from rapidfuzz import fuzz
raw, out = sys.argv[1], sys.argv[2]
s = pd.read_excel(f'{raw}/sssams2015.xlsx', sheet_name=0)
e = pd.read_csv(f'{raw}/enrol_2019.csv')
d = pd.read_excel(f'{raw}/dtm_edu.xlsx', sheet_name=0)
e19 = e.groupby('_SREF').TOTAL.sum()
def norm(x): x = re.sub(r'[^a-z0-9 ]', ' ', str(x).lower()); x = re.sub(r'\b(primary|basic|secondary|school|sch|nursery|and|ps|p s|the|of|community|girls|boys|mixed)\b', ' ', x); return re.sub(r'\s+', ' ', x).strip()
s = s.rename(columns={'Enrolment Female':'EF','Enrolment Male':'EM','Closed Date':'CD'})
s = s[s.Latitude.between(3, 13) & s.Longitude.between(23, 36)].copy()
s['n'] = s.Name.map(norm)
lat, lon = np.radians(s.Latitude.values), np.radians(s.Longitude.values)
cn = {k: [c for c in d.columns if c.startswith(k)][0] for k in ['Name of Education', 'Latitude_Ref', 'Longitude_Ref', '2.a', '2.b If', '2.c']}
dtm = {}; unmatched = []
for r in d.to_dict('records'):
    la, lo = pd.to_numeric(r[cn['Latitude_Ref']], errors='coerce'), pd.to_numeric(r[cn['Longitude_Ref']], errors='coerce')
    if pd.isna(la): continue
    dk = 6371 * np.arccos(np.clip(np.sin(math.radians(la)) * np.sin(lat) + np.cos(math.radians(la)) * np.cos(lat) * np.cos(lon - math.radians(lo)), -1, 1))
    cand = np.where(dk < 5)[0]; best, bs = None, 0
    for i in cand:
        sc = fuzz.token_set_ratio(norm(r[cn['Name of Education']]), s.n.iloc[i]) - 4 * dk[i]
        if sc > bs and sc >= 70: best, bs = i, sc
    if best is not None: dtm[s.Reference.iloc[best]] = r
    else: unmatched.append((r, la, lo))
WIN0, WIN1 = '2018-01-01', '2025-12-31'
C0, C1, CAND = '2020-03-20', '2021-05-02', '2020-10-05'
feats = []
def add(geom, props, status, f, t, ev):
    if f <= t: feats.append({'type': 'Feature', 'geometry': geom, 'properties': {**props, 'status': status, 'valid_from': f, 'valid_to': t, 'evidence': ev}})
def periods(base, base_ev, pre_overlay=None):
    # base status applies 2018-01 to 2020-03-19, then COVID closure, then carried forward base (labelled unobserved)
    out = []
    if pre_overlay:
        f, st, ev = pre_overlay
        if f > WIN0: out.append((base, WIN0, (pd.Timestamp(f) - pd.Timedelta(days=1)).strftime('%Y-%m-%d'), base_ev))
        out.append((st, max(f, WIN0), '2020-03-19', ev))
    else:
        out.append((base, WIN0, '2020-03-19', base_ev))
    out.append(('closed nationally (COVID-19)', C0, C1, 'Presidential order closed all schools 20 Mar 2020; P8/S4 candidate classes resumed 5 Oct 2020; all schools reopened 3 May 2021'))
    after = (pre_overlay[1] if pre_overlay else base)
    out.append((f'{after} [carried forward: not observed after 2019-20]', '2021-05-03', WIN1, base_ev + '; no school-level source after 2019-20, see national_school_closures.csv for heatwave closures (Mar 2024, Feb-Mar 2025)'))
    return out
for r in s.itertuples():
    geom = {'type': 'Point', 'coordinates': [round(r.Longitude, 6), round(r.Latitude, 6)]}
    props = {'school_id': r.Reference, 'name': r.Name, 'type': r.Type, 'state': r.State, 'county': r.County, 'payam': r.Payam,
             'sssams_2015_status': r.Status if isinstance(r.Status, str) else ('Closed' if r.Closed == 1 else 'Open'), 'enrolment_2015': None if pd.isna(r.EF) else int((r.EF or 0) + (0 if pd.isna(r.EM) else r.EM)),
             'enrolment_2019': int(e19[r.Reference]) if r.Reference in e19 else None, 'in_iom_dtm_2019_20': r.Reference in dtm}
    if r.Closed == 1 and not (r.Reference in e19 and e19[r.Reference] > 0):
        add(geom, props, 'closed (SSSAMS)', WIN0, WIN1, f"SSSAMS marks school Closed (closed date {r.CD.date() if not pd.isna(r.CD) else 'n/a'}) and it reports no 2019 enrolment"); continue
    if r.Reference in e19 and e19[r.Reference] > 0: base, ev = 'operating (reported 2019 enrolment)', f'SSSAMS 2019 enrolment export lists {int(e19[r.Reference])} learners'
    elif r.Reference in e19: base, ev = 'listed, zero enrolment reported 2019', 'In SSSAMS 2019 export with 0 learners reported'
    else: base, ev = 'unconfirmed (absent from 2019 SSSAMS export)', 'In SSSAMS 2015 list but absent from Oct 2019 enrolment export'
    ov = None
    if r.Reference in dtm:
        x = dtm[r.Reference]
        if x[cn['2.a']] == 'Non-operational':
            since = pd.to_datetime(x[cn['2.c']], errors='coerce')
            ov = (since.strftime('%Y-%m-%d') if pd.notna(since) else '2019-08-01', 'non-operational (IOM DTM)', f"IOM DTM village assessment Aug 2019-Mar 2020: Non-operational, reason {x[cn['2.b If']]}, since {since.date() if pd.notna(since) else 'unknown'}")
        else: ev += '; IOM DTM (Aug 2019-Mar 2020) found it Operational'
    for st, f, t, evx in periods(base, ev, ov): add(geom, props, st, f, t, evx)
# DTM-only schools not in SSSAMS
for i, (x, la, lo) in enumerate(unmatched):
    geom = {'type': 'Point', 'coordinates': [round(lo, 6), round(la, 6)]}
    props = {'school_id': f'DTM-{i:04d}', 'name': x[cn['Name of Education']], 'type': None, 'state': x['State'], 'county': x['County'], 'payam': x['Payam'], 'sssams_2015_status': None, 'enrolment_2015': None, 'enrolment_2019': None, 'in_iom_dtm_2019_20': True}
    if x[cn['2.a']] == 'Non-operational':
        since = pd.to_datetime(x[cn['2.c']], errors='coerce')
        add(geom, props, 'non-operational (IOM DTM)', max(since.strftime('%Y-%m-%d') if pd.notna(since) else '2019-08-01', WIN0), '2020-03-19', f"IOM DTM: Non-operational, reason {x[cn['2.b If']]}")
        add(geom, props, 'closed nationally (COVID-19)', C0, C1, 'National COVID-19 closure')
        add(geom, props, 'non-operational (IOM DTM) [carried forward: not observed after 2019-20]', '2021-05-03', WIN1, 'No later observation')
    else:
        for st, f, t, evx in periods('operating (IOM DTM 2019-20)', 'IOM DTM village assessment found it Operational (not in SSSAMS 2015 list)'):
            if st.startswith('operating') and t == '2020-03-19': f = '2019-08-01'
            add(geom, props, st, f, t, evx)
json.dump({'type': 'FeatureCollection', 'features': feats}, open(f'{out}/schools_status_2018_2025.geojson', 'w'))
pd.DataFrame([f['properties'] for f in feats]).to_csv(f'{out}/schools_status_2018_2025.csv', index=False)
print('features', len(feats), 'schools', len({f['properties']['school_id'] for f in feats}), 'dtm matched', len(dtm), 'dtm unmatched', len(unmatched))
print(pd.Series([f['properties']['status'] for f in feats]).value_counts())
