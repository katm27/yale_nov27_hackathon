import json, pandas as pd
WIN1 = '2025-12-31'
# name, host facility, lon, lat, first_evidence_date, first_evidence_note
S = [
 ('Juba OSC (Family Protection Centre)', 'Juba Teaching Hospital', 31.60914, 4.85074, '2017-11-01', 'Opened Nov 2017; run by IRC with UNFPA support (UNFPA, 4 Jul 2018)'),
 ('Rumbek OSC', 'Rumbek State Hospital', 29.680838, 6.809527, '2019-12-01', 'Planned Jul 2018 (UNFPA); listed as an existing OSC as of Dec 2019 (FAO/World Bank ELRP GBV action plan)'),
 ('Malualkon OSC', 'Malualkon Hospital (registry: Malualkon PHCC)', 27.625281, 9.01423, '2019-12-01', 'Planned Jul 2018 (UNFPA); listed as existing as of Dec 2019 (FAO ELRP plan)'),
 ('Wau OSC', 'Wau Teaching Hospital', 28.00446, 7.69702, '2019-12-01', 'Planned Jul 2018 (UNFPA); listed as existing as of Dec 2019 (FAO ELRP plan)'),
 ('Bor OSC', 'Bor State Hospital', 31.55588, 6.20645, '2019-12-01', 'Listed as existing as of Dec 2019 (FAO ELRP plan)'),
 ('Malakal OSC', 'Assosa PHCC, Malakal (registry: Assossa PHCU)', 31.6675, 9.5155, '2019-12-01', 'Listed as existing as of Dec 2019 (FAO ELRP plan)'),
 ('Torit OSC', 'Torit State Hospital', 32.576175, 4.406391, '2019-12-01', 'Listed as existing as of Dec 2019 (FAO ELRP plan)'),
 ('Kapoeta OSC', 'Kapoeta Civil Hospital', 33.59156, 4.77239, '2019-12-01', 'Inception in 2019, month not given (UNFPA Q1 2023 newsletter); listed as existing as of Dec 2019'),
 ('Yambio OSC', 'Yambio State Hospital', 28.407555, 4.566149, '2019-12-01', 'Listed as existing as of Dec 2019 (FAO ELRP plan); UNICEF May 2020 sitrep also places social workers in a Yambio OSC'),
 ('Yei OSC', 'Yei (UNICEF: Yei PHCC; mapped at Yei Civil Hospital)', 30.6756, 4.09133, '2020-05-01', 'First evidence: UNICEF South Sudan sitrep, May 2020 (social workers assigned to the Yei one-stop centre)'),
 ('Aweil OSC', 'Aweil (mapped at Aweil Civil Hospital)', 27.398381, 8.768444, '2021-12-01', 'First evidence: World Bank/ELRP action plan, Dec 2021 lists Aweil'),
 ('Kuajok OSC', 'Kuajok State Hospital', 27.98236, 8.29658, '2021-12-01', 'First evidence: World Bank/ELRP action plan, Dec 2021 (table of current OSCs)'),
 ('Bentiu OSC', 'Bentiu State Hospital', 29.80299, 9.2535, '2021-12-01', 'Established during 2021, month not given (UNFPA 2021 annual report: 13th OSC)'),
 ('Bentiu GBV safe house / shelter', 'Bentiu', 29.80299, 9.2535, '2021-12-01', 'Newly established in 2021; 158 survivors accommodated that year (UNFPA 2021 annual report)'),
]
feats = []
for name, host, lon, lat, f0, note in S:
    base = {'name': name, 'host_facility': host, 'service': 'GBV safe house' if 'safe house' in name else 'GBV one-stop centre (clinical management of rape, psychosocial, legal, police)', 'first_evidence': f0}
    a = max(f0, '2018-01-01')
    feats.append({'type': 'Feature', 'geometry': {'type': 'Point', 'coordinates': [lon, lat]}, 'properties': {**base, 'status': 'operating (documented)', 'valid_from': a, 'valid_to': '2023-03-31', 'evidence': note + '; UNFPA Q1 2023 newsletter still counts 13 OSCs in the 10 states and 3 administrative areas'}})
    feats.append({'type': 'Feature', 'geometry': {'type': 'Point', 'coordinates': [lon, lat]}, 'properties': {**base, 'status': 'presumed operating (last confirmed Q1 2023)', 'valid_from': '2023-04-01', 'valid_to': WIN1, 'evidence': 'No closure found; no site-level confirmation after Q1 2023, a period that includes the 2025 funding cuts'}})
json.dump({'type': 'FeatureCollection', 'features': feats}, open('/home/claude/out2/gbv_one_stop_centres_2018_2025.geojson', 'w'), indent=0)
pd.DataFrame([f['properties'] | {'lon': f['geometry']['coordinates'][0], 'lat': f['geometry']['coordinates'][1]} for f in feats]).to_csv('/home/claude/out2/gbv_one_stop_centres_2018_2025.csv', index=False)
print(len(feats))
