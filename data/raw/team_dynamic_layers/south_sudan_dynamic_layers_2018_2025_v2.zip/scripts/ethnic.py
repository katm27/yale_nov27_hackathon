import json, sys, pandas as pd
from shapely.geometry import shape, mapping
raw = sys.argv[1]; out = sys.argv[2]
g = json.load(open(f'{raw}/GeoEPR-2021.geojson'))
epr = pd.read_csv(f'{raw}/EPR-2021.csv'); epr = epr[epr.statename == 'South Sudan']
acd = pd.read_csv(f'{raw}/ACD2EPR-2021.csv'); acd = acd[acd.gwid == 626]
feats = []
for f in g['features']:
    p = f['properties']
    if p['statename'] != 'South Sudan': continue
    e = epr[epr.gwgroupid == p['gwgroupid']].iloc[0]
    links = acd[acd.gwgroupid == p['gwgroupid']]
    geom = shape(f['geometry']).simplify(0.005, preserve_topology=True)
    feats.append({'type': 'Feature', 'geometry': mapping(geom), 'properties': {
        'group': p['group'], 'gwgroupid': int(p['gwgroupid']),
        'valid_from': '2018-01-01', 'valid_to': '2021-12-31',
        'epr_period': f"{p['from']}-{p['to']}",
        'pop_share': float(e['size']), 'power_status': e['status'],
        'settlement_type': p['type'], 'area_sqkm': p['sqkm'],
        'linked_rebel_orgs': '; '.join(f"{r.sideb} (claim={int(r.claim)}, recruitment={int(r.recruitment)})" for r in links.itertuples()) or None,
        'source': 'ETH Zurich GeoEPR-2021 + EPR-2021 core + ACD2EPR-2021',
        'method': 'Downloaded directly; one EPR period (2011-2021) covers all of 2018-2021, so polygons and power status do not change inside the window.'}})
json.dump({'type': 'FeatureCollection', 'features': feats}, open(f'{out}/ethnic_groups_geoepr_2018_2021.geojson', 'w'))
print(len(feats))
