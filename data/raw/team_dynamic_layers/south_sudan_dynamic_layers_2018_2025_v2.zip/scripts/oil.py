import sys, json, glob, pandas as pd
from shapely.geometry import shape
osm, out = sys.argv[1], sys.argv[2]
SYS = {
 'B37': ('Blocks 3 & 7 (Dar Petroleum, Melut Basin) -> Petrodar pipeline to Port Sudan', [
   ('2018-01-01', '2024-02-05', 'operating', 'Producing and exporting Dar Blend via the Petrodar pipeline through Sudan'),
   ('2024-02-06', '2025-01-07', 'halted', 'Exports halted 6 Feb 2024 after the Petrodar pipeline ruptured inside Sudan; Sudan declared force majeure in March 2024 (Radio Tamazuj; Sudan Tribune 30 Apr 2025)'),
   ('2025-01-08', '2025-12-31', 'operating (resumed)', 'Blocks 3 and 7 restarted 8 Jan 2025 after force majeure was lifted; full flows reported by Apr 2025 (Sudan Tribune; Oilprice.com)')]),
 'B124': ('Blocks 1, 2 & 4 (GPOC: Unity, Toma South, El Toor, Munga, El Nar) -> Heglig -> Greater Nile pipeline', [
   ('2018-01-01', '2018-08-24', 'shut in', 'Shut since the Dec 2013 civil war'),
   ('2018-08-25', '2019-01-20', 'partially operating', 'Toma South restarted 25 Aug 2018 (Reuters/Al Jazeera); other Unity fields still shut'),
   ('2019-01-21', '2025-12-07', 'operating', 'Unity fields restarted at a ceremony on 21 Jan 2019 (VOA)'),
   ('2025-12-08', '2025-12-31', 'disrupted', 'RSF seized Heglig, the processing hub for this crude, on 8 Dec 2025; engineers shut it down and evacuated (AFP via New Arab)')]),
 'B5A': ('Block 5A (SPOC, Thar Jath) -> Thar Jath-Heglig line', [
   ('2018-01-01', '2021-06-20', 'shut in', 'Production stopped after 2013-14 fighting'),
   ('2021-06-21', '2025-12-07', 'operating', 'Thar Jath production resumed 21 Jun 2021 after nearly 8 years (Sudan Tribune; Eye Radio)'),
   ('2025-12-08', '2025-12-31', 'disrupted', 'Block 5A crude flows to the Heglig control centre, which the RSF seized and shut on 8 Dec 2025')])}
import geopandas as gpd
ADM = gpd.read_file('/home/claude/raw/bnd/ssd_admin2.geojson').to_crs(4326)
def block(geom):
    c = geom.centroid
    if c.x > 31: return 'B37'
    hit = ADM[ADM.contains(c)]
    county = hit.iloc[0]['adm2_name'] if len(hit) else ''
    return 'B5A' if county in ('Guit', 'Koch', 'Leer', 'Mayendit', 'Panyijiar') else 'B124'
pipes, wells = [], []
for fn in glob.glob(f'{osm}/*/ssd_oil_*.geojson'):
    for x in json.load(open(fn))['features']:
        t = x['properties']['tags']; mm = t.get('man_made')
        if mm not in ('pipeline', 'petroleum_well', 'oil_well'): continue
        if mm == 'pipeline' and (t.get('substance') in ('water',) or 'water' in str(t.get('name', '')).lower()): continue
        g = shape(x['geometry']); b = block(g)
        base = {'osm_id': x['properties']['osm_id'], 'osm_last_edit': x['properties']['timestamp'][:10], 'feature': mm, 'name': t.get('name'), 'operator_tag': t.get('operator'), 'substance_tag': t.get('substance'), 'block_system': SYS[b][0]}
        for f0, f1, st, ev in SYS[b][1]:
            (pipes if mm == 'pipeline' else wells).append({'type': 'Feature', 'geometry': x['geometry'], 'properties': {**base, 'status': st, 'valid_from': f0, 'valid_to': f1, 'evidence': ev}})
json.dump({'type': 'FeatureCollection', 'features': pipes}, open(f'{out}/oil_pipelines_status_2018_2025.geojson', 'w'))
json.dump({'type': 'FeatureCollection', 'features': wells}, open(f'{out}/oil_wells_status_2018_2025.geojson', 'w'))
rows = [dict(block_system=v[0], valid_from=a, valid_to=b, status=s, evidence=e) for v in SYS.values() for a, b, s, e in v[1]]
pd.DataFrame(rows).to_csv(f'{out}/oil_block_status_timeline_2018_2025.csv', index=False)
print(len(pipes), len(wells)); print(pd.Series([p['properties']['block_system'][:12] for p in pipes + wells]).value_counts())
