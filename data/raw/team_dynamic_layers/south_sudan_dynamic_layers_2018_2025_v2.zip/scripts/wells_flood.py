import json, pandas as pd, numpy as np
d = pd.read_csv('/home/claude/raw/s1/s1_wells_ring.csv'); d = d[d.osm_id != 'ERR'].copy()
d['osm_id'] = d.osm_id.astype(int)
for c in ['vv_db_median_500m', 'open_water_share_500m']: d[c] = d[c].astype(float)
d['month'] = d.date.str[:7]
m = d.groupby(['osm_id', 'month']).agg(acquisitions=('date', 'nunique'), open_water_share_500m=('open_water_share_500m', 'median'), vv_db_median_500m=('vv_db_median_500m', 'median')).reset_index()
W = {f['properties']['osm_id']: f for f in json.load(open('/home/claude/raw/s1/wells_unique.geojson'))['features']}
m['block_system'] = m.osm_id.map(lambda i: W[i]['properties']['block_system'])
m['lon'] = m.osm_id.map(lambda i: W[i]['geometry']['coordinates'][0]); m['lat'] = m.osm_id.map(lambda i: W[i]['geometry']['coordinates'][1])
m['flood_water_around_well'] = m.open_water_share_500m >= 0.25
m.round(4).to_csv('/home/claude/out2/oil_wells_flooding_monthly_2018_2025.csv', index=False)
feats = []
for i, g in m.sort_values('month').groupby('osm_id'):
    g = g.reset_index(drop=True); st = None
    for k in range(len(g) + 1):
        v = g.flood_water_around_well[k] if k < len(g) else None
        if st is None: st = (v, k); continue
        if v != st[0]:
            a, b = g.month[st[1]], g.month[k - 1]
            feats.append({'type': 'Feature', 'geometry': W[i]['geometry'], 'properties': {'osm_id': int(i), 'block_system': W[i]['properties']['block_system'],
                'status': 'flood water around well (>=25% of 500 m ring is open water)' if st[0] else 'no open flood water detected',
                'valid_from': a + '-01', 'valid_to': (pd.Period(b).end_time).strftime('%Y-%m-%d'),
                'max_open_water_share': float(g.open_water_share_500m[st[1]:k].max()),
                'evidence': 'Sentinel-1 RTC VV backscatter (Planetary Computer), share of pixels below -15 dB in a 100-500 m ring around the OSM well, monthly median of acquisitions'}})
            st = (v, k)
json.dump({'type': 'FeatureCollection', 'features': feats}, open('/home/claude/out2/oil_wells_flooding_status_2018_2025.geojson', 'w'))
print(len(feats), sum(f['properties']['status'].startswith('flood') for f in feats))
y = m.assign(y=m.month.str[:4]).groupby('y').agg(wells_flooded_any_month=('flood_water_around_well', lambda s: m.loc[s.index][s].osm_id.nunique()), median_share=('open_water_share_500m', 'median'))
print(y)
