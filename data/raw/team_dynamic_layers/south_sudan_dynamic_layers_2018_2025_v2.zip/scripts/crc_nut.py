# County x month presence of protection / GBV / child-protection / MHPSS partners from OCHA 3W, 2019-2025
import sys, re, pandas as pd, geopandas as gpd, json
raw, bnd, out = sys.argv[1:4]
MON = {m.lower()[:3]: i for i, m in enumerate(['January','February','March','April','May','June','July','August','September','October','November','December'], 1)}
MON['mac'] = 3
recs = []
def push(df, y, state, county, org, sector, month):
    d = pd.DataFrame({'state': df[state], 'county': df[county], 'org': df[org], 'sector': df[sector], 'year': y,
                      'month': df[month] if not isinstance(month, int) else month})
    recs.append(d)
for y in [2019, 2020]:
    x = pd.read_excel(f'{raw}/3w_{y}.xlsx', sheet_name=None)
    for s, d in x.items():
        k = s.strip().lower()[:3]
        if k in MON and {'County', 'Sector', 'Acronym'} <= set(d.columns): push(d, y, 'State', 'County', 'Acronym', 'Sector', MON[k])
for y in [2021, 2022]:
    x = pd.read_excel(f'{raw}/3w_{y}.xlsx', sheet_name=None)
    d = max(x.values(), key=len)
    d = d[d['#reporting+or+implementing+org?'].astype(str).str.contains('Implement|Report', case=False)]
    d = d.assign(m=d['#date'].astype(str).str.lower().str[:3].map(MON))
    push(d, y, '#adm1+name', '#adm2+name', '#org+reporting', 'Name', 'm')
d = pd.read_excel(f'{raw}/3w_2023.xlsx'); push(d, 2023, 'State', 'County', 'Organization', 'Sector', 'Month Number')
for y in [2024, 2025]:
    d = pd.read_excel(f'{raw}/3w_{y}.xlsx'); d['m'] = pd.to_datetime(d['Reporting Month'], errors='coerce').dt.month
    push(d, y, 'State', 'County', 'Acronym', 'Cluster', 'm')
a = pd.concat(recs).dropna(subset=['county', 'sector', 'month'])
a['sector'] = a.sector.astype(str).str.strip()
def kind_old(s):
    s = s.lower()
    if 'gbv' in s or 'gender' in s: return 'GBV'
    if 'child' in s or s in ('cp', 'pro-cp'): return 'Child protection'
    if 'mhpss' in s or 'psycho' in s: return 'MHPSS'
    if 'protection' in s or s.startswith('pro'): return 'Nutrition'
    return None
a['service'] = a.sector.map(lambda x: 'Nutrition' if 'nutri' in x.lower() else None)
print(a[a.service.isna()].sector.value_counts().head(25).to_dict())
p = a.dropna(subset=['service'])
p['county_key'] = p.county.astype(str).str.lower().str.replace(r'[^a-z]', '', regex=True)
adm = gpd.read_file(f'{bnd}/ssd_admin2.geojson').to_crs(4326)
adm['county_key'] = adm.adm2_name.str.lower().str.replace(r'[^a-z]', '', regex=True)
alias = {'abyeiregion': 'abyei', 'abyeiadministrativearea': 'abyei', 'abyeiarea': 'abyei', 'luakpinynasir': 'luakpinynasir', 'nasir': 'luakpinynasir', 'canal': 'canalpigi', 'pigi': 'canalpigi', 'kajokeji': 'kajokeji', 'panyikang': 'panyikang', 'pochalla': 'pochalla', 'gpaa': 'pibor', 'pibor': 'pibor', 'ruwengadministrativearea': 'pariang', 'raja': 'raja', 'raga': 'raja', 'longechuk': 'longochuk', 'kapoetaeast': 'kapoetaeast', 'ruwengaa': 'pariang'}
p['county_key'] = p.county_key.replace(alias)
unmatched = sorted(set(p.county_key) - set(adm.county_key))
print('unmatched counties', unmatched)
g = p.groupby(['county_key', 'year', 'month', 'service']).org.nunique().unstack('service', fill_value=0)
g['any_protection_gbv_partner'] = p.groupby(['county_key', 'year', 'month']).org.nunique()
g = g.reset_index()
g['month_start'] = pd.to_datetime(dict(year=g.year, month=g.month.astype(int), day=1)).dt.strftime('%Y-%m-%d')
g = g.merge(adm[['county_key', 'adm2_name', 'adm2_pcode', 'adm1_name']], on='county_key', how='inner')
# fill months with no protection rows as 0 where the 3W was reported that month
months = a.assign(ms=pd.to_datetime(dict(year=a.year, month=a.month.astype(int), day=1)).dt.strftime('%Y-%m-%d')).ms.unique()
full = pd.MultiIndex.from_product([adm.adm2_pcode, sorted(months)], names=['adm2_pcode', 'month_start']).to_frame(index=False)
full = full.merge(adm[['adm2_pcode', 'adm2_name', 'adm1_name']], on='adm2_pcode')
cols = ['Nutrition', 'any_protection_gbv_partner']
g = full.merge(g[['adm2_pcode', 'month_start'] + [c for c in cols if c in g]], on=['adm2_pcode', 'month_start'], how='left').fillna({c: 0 for c in cols})
for c in cols:
    if c in g: g[c] = g[c].astype(int)
g['valid_from'] = g.month_start; g['valid_to'] = (pd.to_datetime(g.month_start) + pd.offsets.MonthEnd(0)).dt.strftime('%Y-%m-%d')
g = g.sort_values(['adm2_pcode', 'month_start'])
g['change_vs_prev_month'] = g.groupby('adm2_pcode').any_protection_gbv_partner.diff()
g = g.drop(columns=[c for c in ['Nutrition'] if c in g]).rename(columns={'any_protection_gbv_partner': 'nutrition_partners_active', 'change_vs_prev_month': 'partner_change_vs_prev_month'})
g.to_csv(f'{out}/nutrition_partner_presence_county_month_2019_2025.csv', index=False)
print(g.shape, sorted(months)[:3], sorted(months)[-3:], len(months))
print(g.groupby(g.month_start.str[:4]).nutrition_partners_active.agg(['mean','sum'])); print((g.nutrition_partners_active==0).groupby(g.month_start.str[:4]).mean())
