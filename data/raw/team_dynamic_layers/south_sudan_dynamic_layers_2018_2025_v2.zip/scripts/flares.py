# Detect persistent gas-flare hotspots in MODIS 8-day fire masks and build monthly operating signals per flare site.
import sys, json, numpy as np, pandas as pd, geopandas as gpd
from shapely.geometry import Point, MultiPoint, mapping
modis, osmdir, bnd, out = sys.argv[1:5]
f = pd.read_csv(f'{modis}/fire_pixels.csv', parse_dates=['start'])
comp = pd.read_csv(f'{modis}/composites.csv', parse_dates=['start'])
f['pix'] = f.tile + '_' + f.row.astype(str) + '_' + f.col.astype(str)
f['wet'] = f.start.dt.month.isin([6, 7, 8, 9])
f['period'] = f.start.dt.strftime('%Y-%j')
g = f.groupby('pix').agg(lon=('lon', 'mean'), lat=('lat', 'mean'), n_periods=('period', 'nunique'),
                         wet_periods=('period', lambda s: s[f.loc[s.index, 'wet']].nunique()))
# flare rule: detected in >=4 distinct Jun-Sep composites over 2018-2025 (vegetation fire is near absent then)
fl = g[g.wet_periods >= 4].copy()
print('candidate flare pixels', len(fl))
# cluster pixels within ~3 km
pts = fl[['lon', 'lat']].values; lab = -np.ones(len(fl), int); k = 0
for i in range(len(fl)):
    if lab[i] >= 0: continue
    stack = [i]; lab[i] = k
    while stack:
        j = stack.pop()
        d = np.hypot((pts[:, 0] - pts[j, 0]) * np.cos(np.radians(pts[j, 1])), pts[:, 1] - pts[j, 1]) * 111
        for m in np.where((d < 3) & (lab < 0))[0]: lab[m] = k; stack.append(m)
    k += 1
fl['site'] = lab
adm = gpd.read_file([p for p in __import__('glob').glob(f'{bnd}/*admin2*.geojson')][0]).to_crs(4326)
adm1 = gpd.read_file([p for p in __import__('glob').glob(f'{bnd}/*admin1*.geojson')][0]).to_crs(4326)
sites = []
months = pd.period_range('2018-01', '2025-12', freq='M')
# neighbourhood: any fire pixel within 2 km of a site's flare pixels counts as site detection (flare footprint drifts across pixel edges)
rows = []
for s, grp in fl.groupby('site'):
    hull = MultiPoint(grp[['lon', 'lat']].values.tolist()).convex_hull.buffer(0.018)
    sel = f[(f.lon.between(hull.bounds[0], hull.bounds[2])) & (f.lat.between(hull.bounds[1], hull.bounds[3]))]
    sel = sel[[hull.contains(Point(x, y)) for x, y in zip(sel.lon, sel.lat)]]
    c = hull.centroid
    a2 = adm[adm.contains(c)]; a1 = adm1[adm1.contains(c)]
    country = 'South Sudan' if len(a1) else 'Sudan (outside South Sudan; likely Heglig/Bamboo processing area)' if c.y > 9 else 'outside South Sudan'
    m = sel.groupby(sel.start.dt.to_period('M')).period.nunique().reindex(months, fill_value=0)
    nobs = comp.groupby(comp.start.dt.to_period('M')).id.nunique().reindex(months, fill_value=0)
    sites.append(dict(site_id=f'FLARE-{s:02d}', lon=c.x, lat=c.y, n_pixels=len(grp), wet_periods_total=int(grp.wet_periods.sum()),
                      county=a2.iloc[0]['adm2_name'] if len(a2) else None, state=a1.iloc[0]['adm1_name'] if len(a1) else None, country=country, geom=hull))
    for per, v in m.items(): rows.append(dict(site_id=f'FLARE-{s:02d}', month=str(per), composites_with_flare=int(v)))
mon = pd.DataFrame(rows)
mon['active'] = mon.composites_with_flare > 0
S = pd.DataFrame(sites)
# runs -> status periods, bridging gaps of <=2 inactive months between active months
feats = []
for sid, grp in mon.groupby('site_id'):
    a = grp.sort_values('month').active.values.copy(); ms = grp.sort_values('month').month.values
    idx = np.where(a)[0]
    for i0, i1 in zip(idx[:-1], idx[1:]):
        if 1 < i1 - i0 <= 3: a[i0 + 1:i1] = True
    st = None
    for i, v in enumerate(list(a) + [None]):
        if st is None: st = (v, i); continue
        if v != st[0]:
            srow = S[S.site_id == sid].iloc[0]
            f0 = pd.Period(ms[st[1]]).start_time.strftime('%Y-%m-%d'); f1 = pd.Period(ms[i - 1]).end_time.strftime('%Y-%m-%d')
            feats.append({'type': 'Feature', 'geometry': mapping(Point(round(srow.lon, 5), round(srow.lat, 5))), 'properties': {
                'site_id': sid, 'status': 'flaring detected (operating signal)' if st[0] else 'no flare detected (possible shut-in)',
                'valid_from': f0, 'valid_to': f1, 'months': i - st[1], 'county': srow.county, 'state': srow.state, 'country': srow.country,
                'evidence': 'NASA MODIS MOD14A2/MYD14A2 8-day thermal anomalies (Terra+Aqua, 1 km) via Microsoft Planetary Computer; gaps of up to 2 months between detections bridged'}})
            st = (v, i)
json.dump({'type': 'FeatureCollection', 'features': feats}, open(f'{out}/oil_flare_sites_status_2018_2025.geojson', 'w'))
mon.merge(S[['site_id', 'county', 'state', 'country', 'lon', 'lat']], on='site_id').to_csv(f'{out}/oil_flare_sites_monthly_2018_2025.csv', index=False)
S.drop(columns='geom').to_csv(f'{modis}/flare_sites.csv', index=False)
print(S.drop(columns='geom').to_string())
pv = mon.pivot(index='site_id', columns='month', values='composites_with_flare')
yr = mon.assign(y=mon.month.str[:4]).groupby(['site_id', 'y']).active.sum().unstack()
print(yr.to_string())
