import sys, json, pandas as pd, numpy as np
raw, out = sys.argv[1], sys.argv[2]
sys.path.insert(0, '/home/claude/scripts')
AOIS = {
 'WhiteNile_Juba': (31.615, 4.840, 'control: White Nile upstream of all oil areas'),
 'WhiteNile_Bor': (31.570, 6.210, 'control: White Nile, Jonglei'),
 'WhiteNile_Malakal': (31.650, 9.550, 'upstream reference for Melut Basin oil'),
 'WhiteNile_Melut': (32.200, 10.440, 'adjacent to Melut Basin oil (Blocks 3 & 7)'),
 'WhiteNile_Renk': (32.790, 11.750, 'downstream of Melut Basin oil'),
 'Sobat_Nasir': (33.070, 8.610, 'control: Sobat river, no oil production'),
 'Unity_Bentiu_wetland': (29.790, 9.250, 'wetland/river near Unity oil fields (Blocks 1, 2 & 4)'),
 'TharJath_wetland': (30.000, 8.500, 'Sudd edge near Thar Jath (Block 5A)')}
H = 0.05
d = pd.concat([pd.read_csv(f'{raw}/hls_scenes_part1.csv'), pd.read_csv(f'{raw}/hls_scenes.csv'), pd.read_csv(f'{raw}/s2_fill_scenes.csv')]).drop_duplicates('scene')
d = d[~((d.sensor != 'sentinel-2-l2a') & (d.date < '2020-01-01') & (d.sensor == 'hls2-l30') & False)]
print('scenes', len(d), 'errors', d.error.notna().sum())
d = d[(d.water_px >= 150) & d.ndti.notna()].copy()
d['month'] = d.date.str[:7]
m = d.groupby(['aoi', 'month']).agg(scenes=('scene', 'nunique'), sensors=('sensor', lambda x: '+'.join(sorted(set(x)))), water_px_median=('water_px', 'median'), ndti=('ndti', 'median'), red_reflectance=('red', 'median'), ndci=('ndci', 'median')).reset_index()
m['cal_month'] = m.month.str[5:7]
clim = m.groupby(['aoi', 'cal_month'])[['ndti', 'ndci']].median().rename(columns={'ndti': 'ndti_clim', 'ndci': 'ndci_clim'})
m = m.merge(clim, on=['aoi', 'cal_month'])
m['ndti_anomaly'] = m.ndti - m.ndti_clim; m['ndci_anomaly'] = m.ndci - m.ndci_clim
m['valid_from'] = m.month + '-01'; m['valid_to'] = (pd.to_datetime(m.valid_from) + pd.offsets.MonthEnd(0)).dt.strftime('%Y-%m-%d')
m['role'] = m.aoi.map(lambda a: AOIS[a][2]); m['lon'] = m.aoi.map(lambda a: AOIS[a][0]); m['lat'] = m.aoi.map(lambda a: AOIS[a][1])
m = m.drop(columns=['cal_month']).sort_values(['aoi', 'month'])
m.round(5).to_csv(f'{out}/surface_water_optical_quality_monthly_2018_2025.csv', index=False)
feats = []
for r in m.itertuples():
    x, y = r.lon, r.lat
    feats.append({'type': 'Feature', 'geometry': {'type': 'Polygon', 'coordinates': [[[x - H, y - H], [x + H, y - H], [x + H, y + H], [x - H, y + H], [x - H, y - H]]]},
        'properties': {k: (None if (isinstance(v, float) and np.isnan(v)) else (round(v, 5) if isinstance(v, float) else v)) for k, v in r._asdict().items() if k not in ('Index', 'lon', 'lat')}})
json.dump({'type': 'FeatureCollection', 'features': feats}, open(f'{out}/surface_water_optical_quality_monthly_2018_2025.geojson', 'w'))
print(m.groupby('aoi').agg(months=('month', 'nunique'), ndti=('ndti', 'median'), ndci=('ndci', 'median')))
print(m.assign(y=m.month.str[:4]).pivot_table(index='aoi', columns='y', values='ndti', aggfunc='median').round(3))
