# NASA HLS (Landsat+Sentinel-2, 30 m) surface-water optical quality per AOI per scene, 2018-2025.
# Water = Fmask water bit set and no cloud / adjacent-cloud / shadow bits. Indices from water pixels only.
import sys, csv, numpy as np, rasterio, planetary_computer as pc
from rasterio.windows import from_bounds
from rasterio.warp import transform_bounds
from pystac_client import Client
from concurrent.futures import ThreadPoolExecutor
out = sys.argv[1]
AOIS = {  # name: (lon, lat, role)
 'WhiteNile_Juba': (31.615, 4.840, 'control: White Nile upstream of all oil areas'),
 'WhiteNile_Bor': (31.570, 6.210, 'control: White Nile, Jonglei'),
 'WhiteNile_Malakal': (31.650, 9.550, 'upstream reference for Melut Basin oil'),
 'WhiteNile_Melut': (32.200, 10.440, 'adjacent to Melut Basin oil (Blocks 3 & 7)'),
 'WhiteNile_Renk': (32.790, 11.750, 'downstream of Melut Basin oil'),
 'Sobat_Nasir': (33.070, 8.610, 'control: Sobat river, no oil production'),
 'Unity_Bentiu_wetland': (29.790, 9.250, 'wetland/river near Unity oil fields (Blocks 1, 2 & 4)'),
 'TharJath_wetland': (30.000, 8.500, 'Sudd edge near Thar Jath (Block 5A)'),
}
H = 0.05
cat = Client.open('https://planetarycomputer.microsoft.com/api/stac/v1', modifier=pc.sign_inplace)
jobs = []
for name, (x, y, role) in AOIS.items():
    bb = [x - H, y - H, x + H, y + H]
    for col in ['hls2-s30', 'hls2-l30']:
        its = list(cat.search(collections=[col], bbox=bb, datetime='2018-01-01/2025-12-31', query={'eo:cloud_cover': {'lt': 80}}).items())
        print(name, col, len(its), flush=True)
        jobs += [(name, bb, col, it) for it in its]
import pandas as pd, os
# keep at most 3 least-cloudy scenes per AOI per month (S30 preferred), skip scenes already processed
done = set(pd.read_csv(f'{out}/hls_scenes_part1.csv').scene) if os.path.exists(f'{out}/hls_scenes_part1.csv') else set()
df = pd.DataFrame([dict(i=i, aoi=j[0], col=j[2], m=j[3].datetime.strftime('%Y-%m'), cc=j[3].properties.get('eo:cloud_cover', 100), sid=j[3].id) for i, j in enumerate(jobs)])
df['pri'] = (df.col != 'hls2-s30').astype(int)
keep = df.sort_values(['pri', 'cc']).groupby(['aoi', 'm']).head(3)
keep = keep[~keep.sid.isin(done)]
jobs = [jobs[i] for i in sorted(keep.i)]
print('selected jobs', len(jobs), flush=True)
def rd(href, bb):
    with rasterio.open(href) as s:
        b = transform_bounds('EPSG:4326', s.crs, *bb)
        w = from_bounds(*b, s.transform).round_offsets().round_lengths()
        return s.read(1, window=w, boundless=True, fill_value=s.nodata if s.nodata is not None else 0)
def work(j):
    name, bb, col, it = j
    try:
        fm = rd(it.assets['Fmask'].href, bb)
        water = ((fm >> 5) & 1 == 1) & ((fm >> 1) & 1 == 0) & ((fm >> 2) & 1 == 0) & ((fm >> 3) & 1 == 0) & (fm != 255)
        clear = ((fm >> 1) & 1 == 0) & ((fm >> 3) & 1 == 0) & (fm != 255)
        n = int(water.sum())
        row = dict(aoi=name, date=it.datetime.strftime('%Y-%m-%d'), sensor=col, scene=it.id, water_px=n, clear_px=int(clear.sum()), total_px=int(fm.size))
        if n < 150: return row
        g = rd(it.assets['B03'].href, bb).astype('float32') * 1e-4
        r = rd(it.assets['B04'].href, bb).astype('float32') * 1e-4
        ok = water & (g > 0) & (r > 0) & (g < 0.5) & (r < 0.5)
        gg, rr = g[ok], r[ok]
        row.update(green=float(np.median(gg)), red=float(np.median(rr)), ndti=float(np.median((rr - gg) / (rr + gg))))
        if col == 'hls2-s30':
            re = rd(it.assets['B05'].href, bb).astype('float32') * 1e-4
            ok2 = ok & (re > 0) & (re < 0.5)
            row['ndci'] = float(np.median((re[ok2] - r[ok2]) / (re[ok2] + r[ok2]))) if ok2.sum() > 100 else None
        return row
    except Exception as e:
        return dict(aoi=name, date=it.datetime.strftime('%Y-%m-%d'), sensor=col, scene=it.id, error=str(e)[:100])
cols = ['aoi', 'date', 'sensor', 'scene', 'water_px', 'clear_px', 'total_px', 'green', 'red', 'ndti', 'ndci', 'error']
with ThreadPoolExecutor(48) as ex, open(f'{out}/hls_scenes.csv', 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=cols); w.writeheader()
    for i, r in enumerate(ex.map(work, jobs)):
        w.writerow(r)
        if i % 250 == 0: print(i, len(jobs), flush=True)
print('done', flush=True)
